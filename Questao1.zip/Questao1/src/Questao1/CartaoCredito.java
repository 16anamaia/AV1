package Questao1;

public class CartaoCredito {
    private String dados;

    public CartaoCredito(String dados) {
        this.dados = dados;
    }

    public void imprimirCupomFiscal() {
        System.out.println("Cupom Fiscal");
        System.out.println("Dados do Cartão: " + dados);

    }

    public static void main(String[] args) {
        Pagamento.imprimirCumpomFiscal cartao = new Pagamento.imprimirCumpomFiscal("mocados");

    }
}
