package Questao1;

public class Pix {
    private String dados;

    public Pix(String dados) {
        this.dados = dados;
    }

    public void imprimirInformacoesPix() {
        System.out.println("Dados da transação Pix: " + dados);
    }
    public static void main(String[] args) {
        Questao2.Pix transacaoPix = new Questao2.Pix("mocados");

        transacaoPix.imprimirInformacoesPix();
    }
}
