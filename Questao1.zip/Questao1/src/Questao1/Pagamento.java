package Questao1;

public class Pagamento {
    private String dataHoraPagamento;
    private int numeroPagamento;
    private double valorPago;

    public Pagamento(String dataHoraPagamento, int numeroPagamento, double valorPago) {
        String dataHoraPagamento1 = this.dataHoraPagamento;
        int numeroPagamento1 = this.numeroPagamento;
        double valorPago1 = this.valorPago;
    }

    public String imprimirCupomFiscal(){
        return null;
    }

    public static class imprimirCumpomFiscal {
    }
}




}
