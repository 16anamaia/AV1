package Questao2;

public class Pessoa {
    private String nome;
    private String email;
    private String senha;

    public void Pessoa(String nome) {
       this.nome = nome;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setSenha() {
        this.senha = senha;
    }
    public class Professor {
        private double salarioHora;
        private int horasAula;

        public Professor(double salarioHora, int horasAula) {
            this.salarioHora = salarioHora;
            this.horasAula = horasAula;
        }

        public double calculaSalario() {
            return salarioHora * horasAula;
        }

        public static void main(String[] args) {
            Professor professor = new Professor(20.0, 40);

            double salario = professor.calculaSalario();

            System.out.println("Salário do professor: R$" + salario);
        }
    }

