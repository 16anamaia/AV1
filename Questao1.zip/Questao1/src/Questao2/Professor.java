package Questao2;

public class Professor {
    private String salarioHora;
    private int horasAulas;
    private float calculaSalario;
    private String mostraProfessor;

    public float getCalculaSalario() {
        return calculaSalario;
    }

    public int getHorasAulas() {
        return horasAulas;
    }
}
