package Questao2;

public class Aluno {
    private int periodo;
    private int turma;
    private String mostraAluno;

    public String getMostraAluno() {
        return mostraAluno;
    }
}
